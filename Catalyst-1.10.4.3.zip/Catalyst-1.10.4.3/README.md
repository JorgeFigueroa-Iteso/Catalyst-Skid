Minecaft Forge Utility Mod Designed for the anarchy environment.
Made By Krazzzzymonkey, blockparole and Pr3roxDLC  
Artwork by LilGanja1337  
<p align="center">
Building The Source
</p>
Use cmd/terminal to build the client with gradlew using the following commads.

```
gradlew setupdecompworkspace
```

```
gradlew clean
```

```
gradlew build
```

