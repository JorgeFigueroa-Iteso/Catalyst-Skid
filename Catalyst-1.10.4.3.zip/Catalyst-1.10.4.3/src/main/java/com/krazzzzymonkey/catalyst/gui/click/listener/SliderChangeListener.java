package com.krazzzzymonkey.catalyst.gui.click.listener;

import com.krazzzzymonkey.catalyst.gui.click.elements.Slider;

public interface SliderChangeListener {

    void onSliderChange(Slider slider);
}
