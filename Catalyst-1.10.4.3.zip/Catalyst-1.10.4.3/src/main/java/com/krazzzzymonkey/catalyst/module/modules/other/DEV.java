package com.krazzzzymonkey.catalyst.module.modules.other;
/*
import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.module.Modules;
import com.krazzzzymonkey.catalyst.value.types.NumberValue;

public class DEV extends Modules {


    public static NumberValue Ver1first;
    public static NumberValue Ver1second;
    public static NumberValue ver1third;

    public static NumberValue Ver2first;
    public static NumberValue Ver2second;
    public static NumberValue ver2third;

    public static NumberValue Ver3first;
    public static NumberValue Ver3second;
    public static NumberValue ver3third;

    public static NumberValue Ver4first;
    public static NumberValue Ver4second;
    public static NumberValue ver4third;

    public static NumberValue Ver5first;
    public static NumberValue Ver5second;
    public static NumberValue ver5third;

    public static NumberValue Ver6first;
    public static NumberValue Ver6second;
    public static NumberValue ver6third;

    public static NumberValue Ver7first;
    public static NumberValue Ver7second;
    public static NumberValue ver7third;

    public static NumberValue Ver8first;
    public static NumberValue Ver8second;
    public static NumberValue ver8third;



    public DEV() {

        super("DEV", ModuleCategory.MISC, "");

        Ver1first = new NumberValue("VER 1 First", 0D, -2D, 2D);
        Ver1second = new NumberValue("VER 1 second", 0D, -2D, 2D);
        ver1third = new NumberValue("VER 1 third", 0D, -2D, 2D);

        Ver2first = new NumberValue("VER 2 First", 0D, -2D, 2D);
        Ver2second = new NumberValue("VER 2 second", 0D, -2D, 2D);
        ver2third = new NumberValue("VER 2 third", 0D, -2D, 2D);


        Ver3first = new NumberValue("VER 3 First", 0D, -2D, 2D);
        Ver3second = new NumberValue("VER 3 second", 0D, -2D, 2D);
        ver3third = new NumberValue("VER 3 third", 0D, -2D, 2D);


        Ver4first = new NumberValue("VER 4 First", 0D, -2D, 2D);
        Ver4second = new NumberValue("VER 4 second", 0D, -2D, 2D);
        ver4third = new NumberValue("VER 4 third", 0D, -2D, 2D);


        Ver5first = new NumberValue("VER 5 First", 0D, -2D, 2D);
        Ver5second = new NumberValue("VER 5 second", 0D, -2D, 2D);
        ver5third = new NumberValue("VER 5 third", 0D, -2D, 2D);


        Ver6first = new NumberValue("VER 6 First", 0D, -2D, 2D);
        Ver6second = new NumberValue("VER 6 second", 0D, -2D, 2D);
        ver6third = new NumberValue("VER 6 third", 0D, -2D, 2D);


        Ver7first = new NumberValue("VER 7 First", 0D, -2D, 2D);
        Ver7second = new NumberValue("VER 7 second", 0D, -2D, 2D);
        ver7third = new NumberValue("VER 7 third", 0D, -2D, 2D);


        Ver8first = new NumberValue("VER 8 First", 0D, -2D, 2D);
        Ver8second = new NumberValue("VER 8 second", 0D, -2D, 2D);
        ver8third = new NumberValue("VER 8 third", 0D, -2D, 2D);






        this.addValue(
                Ver1first,Ver1second,ver1third,
                Ver2first,Ver2second,ver2third,
                Ver3first,Ver3second,ver3third,
                Ver4first,Ver4second,ver4third,
                Ver5first,Ver5second,ver5third,
                Ver6first,Ver6second,ver6third,
                Ver7first,Ver7second,ver7third,
                Ver8first,Ver8second,ver8third);
    }

    public static double Ver1First(){
        double health = Ver1first.getValue();
        return health;
    }
    public static double Ver1Second(){
        double health = Ver1second.getValue();
        return health;
    }
    public static double Ver1third(){
        double health = ver1third.getValue();
        return health;
    }


    public static double Ver2First(){
        double health = Ver2first.getValue();
        return health;
    }
    public static double Ver2Second(){
        double health = Ver2second.getValue();
        return health;
    }
    public static double Ver2third(){
        double health = ver2third.getValue();
        return health;
    }


    public static double Ver3First(){
        double health = Ver3first.getValue();
        return health;
    }
    public static double Ver3Second(){
        double health = Ver3second.getValue();
        return health;
    }
    public static double Ver3third(){
        double health = ver3third.getValue();
        return health;
    }


    public static double Ver4First(){
        double health = Ver4first.getValue();
        return health;
    }
    public static double Ver4Second(){
        double health = Ver4second.getValue();
        return health;
    }
    public static double Ver4third(){
        double health = ver4third.getValue();
        return health;
    }


    public static double Ver5First(){
        double health = Ver5first.getValue();
        return health;
    }
    public static double Ver5Second(){
        double health = Ver5second.getValue();
        return health;
    }
    public static double Ver5third(){
        double health = ver5third.getValue();
        return health;
    }


    public static double Ver6First(){
        double health = Ver6first.getValue();
        return health;
    }
    public static double Ver6Second(){
        double health = Ver6second.getValue();
        return health;
    }
    public static double Ver6third(){
        double health = ver6third.getValue();
        return health;
    }



    public static double Ver7First(){
        double health = Ver7first.getValue();
        return health;
    }
    public static double Ver7Second(){
        double health = Ver7second.getValue();
        return health;
    }
    public static double Ver7third(){
        double health = ver7third.getValue();
        return health;
    }


    public static double Ver8First(){
        double health = Ver8first.getValue();
        return health;
    }
    public static double Ver8Second(){
        double health = Ver8second.getValue();
        return health;
    }
    public static double Ver8third(){
        double health = ver8third.getValue();
        return health;
    }


}*/