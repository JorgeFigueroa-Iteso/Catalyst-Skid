package com.krazzzzymonkey.catalyst.managers.accountManager.legacySupport;

public interface ILegacyCompat {
	int[] getDate();
	String getFormattedDate();
}
