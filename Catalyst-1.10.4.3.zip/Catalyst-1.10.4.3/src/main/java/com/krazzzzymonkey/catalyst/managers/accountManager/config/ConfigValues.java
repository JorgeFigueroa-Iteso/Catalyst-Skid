package com.krazzzzymonkey.catalyst.managers.accountManager.config;
/**
 * This is where you store the config information
 * @author The_Fireplace
 *
 */
public class ConfigValues {
	public static boolean CASESENSITIVE;
	public static boolean ENABLERELOG;
}
