package com.krazzzzymonkey.catalyst.module.modules.hud;

import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.module.Modules;

public class CustomFont extends Modules {

    public CustomFont() {
        super("CustomFont", ModuleCategory.HUD, "Toggles custom font on hud components", true);
    }

}
