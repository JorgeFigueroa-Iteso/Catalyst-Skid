package com.krazzzzymonkey.catalyst.lib.texts;

public interface IText
{
	String get();
}
