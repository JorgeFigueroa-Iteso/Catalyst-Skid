package com.krazzzzymonkey.catalyst.gui.click.listener;

import com.krazzzzymonkey.catalyst.gui.click.base.Component;

public interface ComponentClickListener {

    void onComponenetClick(Component component, int button);

}
