package com.krazzzzymonkey.catalyst.lib;

public enum MODE
{
	FILL, STRETCH, CENTER, TILE
}