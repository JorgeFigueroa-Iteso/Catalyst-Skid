package com.krazzzzymonkey.catalyst.lib;

public enum ANCHOR {
    START, MIDDLE, END
}
