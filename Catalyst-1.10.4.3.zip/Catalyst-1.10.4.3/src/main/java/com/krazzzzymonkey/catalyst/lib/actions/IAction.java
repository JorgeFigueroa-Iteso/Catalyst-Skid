package com.krazzzzymonkey.catalyst.lib.actions;

import com.krazzzzymonkey.catalyst.gui.GuiCustom;

public interface IAction
{
	void perform(Object source, GuiCustom parent);
}
