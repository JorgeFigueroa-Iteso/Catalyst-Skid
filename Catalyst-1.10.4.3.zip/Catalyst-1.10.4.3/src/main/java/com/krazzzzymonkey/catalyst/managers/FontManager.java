package com.krazzzzymonkey.catalyst.managers;

public class FontManager {
    public static String font = "Arial";

    public FontManager(){
        FileManager.loadFont();
    }
}

