package com.krazzzzymonkey.catalyst.brainfuck;

public class BrainfuckException extends RuntimeException {
    public BrainfuckException(String message) {
        super(message);
    }
}
