package com.krazzzzymonkey.catalyst.lib.textures;

public interface ITexture
{
	void bind();
}
