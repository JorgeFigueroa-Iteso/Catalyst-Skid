package com.krazzzzymonkey.catalyst.configuration;

public class Alignment
{
	public float factorX;
	public float factorY;

	public Alignment(float factorX, float factorY)
	{
		this.factorX = factorX;
		this.factorY = factorY;
	}
}
