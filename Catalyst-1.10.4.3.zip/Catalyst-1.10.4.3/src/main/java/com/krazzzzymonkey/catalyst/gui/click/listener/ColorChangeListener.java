package com.krazzzzymonkey.catalyst.gui.click.listener;

import com.krazzzzymonkey.catalyst.gui.click.elements.ColorPicker;

public interface ColorChangeListener {
    void onColorChangeClick(ColorPicker checkButton);
}
