package com.krazzzzymonkey.catalyst.utils;

public class LogOutSpot {

    public double x;
    public double y;
    public double z;
    public String name;

    public LogOutSpot(double x, double y, double z, String name) {

        this.x = x;
        this.y = y;
        this.z = z;
        this.name = name;

    }
}
