package com.krazzzzymonkey.catalyst.gui.click.listener;

import com.krazzzzymonkey.catalyst.gui.click.elements.ComboBox;

public interface ComboBoxListener {

    void onComboBoxSelectionChange(ComboBox comboBox);

}
