package com.krazzzzymonkey.catalyst.managers;

public enum SoundTypes {
    KILL,
    HIT,
    POP,
    EXPLOSION
}
