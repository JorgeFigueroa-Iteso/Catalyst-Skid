package com.krazzzzymonkey.catalyst.module;

public enum ModuleCategory {
 CHAT, COMBAT, GUI, MISC, MOVEMENT, PLAYER, RENDER, WORLD, HUD, CUSTOM
}
