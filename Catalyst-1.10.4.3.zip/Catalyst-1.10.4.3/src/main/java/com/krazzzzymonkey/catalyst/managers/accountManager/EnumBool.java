package com.krazzzzymonkey.catalyst.managers.accountManager;

public enum EnumBool {
	TRUE,
	FALSE,
	UNKNOWN
}
